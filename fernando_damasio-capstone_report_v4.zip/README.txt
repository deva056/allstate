########################
# CAPSTONE PROJECT
# Fernando Damasio
# fernando@cashflix.com.br
# November 10, 2016
########################

- The file is a python 2.7 notebook.
- The only parameter to be changed in the code is the data directory.
- Working with 6 cores for prediction, all the code should run in 4 hours.
- RAM: 6 GB.

The libraries used are very common and must not need aditional preparation:
* Pandas
* Numpy
* Time
* Scipy
* Sklearn
* Seaborn
